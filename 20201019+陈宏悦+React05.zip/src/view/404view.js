import React from 'react';
export default function View404() {
  return <h1>页面飞走了</h1>;
}
